DROP TABLE IF EXISTS `#__banners`;

DROP TABLE IF EXISTS `#__banner_clients`;

DROP TABLE IF EXISTS `#__banner_tracks`;

